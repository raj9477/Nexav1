import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.nexa.assistant",
  appName: "Nexa",
  webDir: "dist",
  android: {
    allowMixedContent: false
  }
};

export default config;
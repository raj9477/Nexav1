# Nexa AI Assistant

Original starter project for the Nexa Android assistant.

## Stack
- React + TypeScript
- Vite
- Capacitor 7
- Native Android bridge placeholder

## Run on PC
```bash
npm install
npm run dev
```

## Build web bundle
```bash
npm run build
```

## Create Android project
Run:
```bash
npm install
npm run build
npx cap add android
npx cap sync android
```

Then open the Android project in Android Studio:
```bash
npx cap open android
```

## Planned native phases
1. Real AI backend / Gemini integration
2. Native Android app launcher
3. Notification access
4. Contacts and call actions
5. Media controls
6. Background service
7. Wake-word engine
8. Secure local memory
9. Optional cloud sync/auth (not required for V1)

The current project intentionally has no login system.

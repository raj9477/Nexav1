import { useMemo, useState } from "react";
import { Bot, Brain, Clock3, Mic, Send, Settings, Sparkles, Volume2, X } from "lucide-react";
import { addMemory, getMemories } from "./services/MemoryService";
import { listen, speak } from "./services/VoiceService";

type Message = { role: "user" | "nexa"; text: string };

function generateReply(input: string): string {
  const q = input.toLowerCase();
  if (q.includes("hello") || q.includes("hi")) return "Hey! I'm Nexa. What are we working on?";
  if (q.includes("time")) return `Your device time is ${new Date().toLocaleTimeString()}.`;
  if (q.includes("remember")) return "Tell me exactly what you want me to remember.";
  return "I'm connected to the Nexa interface. The AI backend can be plugged into this layer next.";
}

export default function App() {
  const [messages, setMessages] = useState<Message[]>([
    { role: "nexa", text: "Nexa online. Ready when you are." }
  ]);
  const [input, setInput] = useState("");
  const [listening, setListening] = useState(false);
  const [showMemory, setShowMemory] = useState(false);
  const [memories, setMemories] = useState(getMemories());

  const status = useMemo(() => listening ? "Listening…" : "Online", [listening]);

  function send(text = input) {
    const clean = text.trim();
    if (!clean) return;
    const reply = generateReply(clean);
    setMessages(m => [...m, { role: "user", text: clean }, { role: "nexa", text: reply }]);
    setInput("");
    speak(reply);
  }

  function startVoice() {
    if (listening) return;
    const session = listen(t => send(t), setListening);
    if (!session) alert("Voice recognition is not available on this device/browser yet.");
  }

  function remember() {
    const text = prompt("What should Nexa remember?");
    if (!text?.trim()) return;
    addMemory(text.trim());
    setMemories(getMemories());
  }

  return (
    <main className="app">
      <aside className="sidebar">
        <div className="brand"><div className="logo"><Sparkles size={21}/></div><div><b>Nexa</b><small>AI ASSISTANT</small></div></div>
        <button className="side-btn active"><Bot size={18}/> Assistant</button>
        <button className="side-btn" onClick={() => setShowMemory(true)}><Brain size={18}/> Memory</button>
        <button className="side-btn"><Clock3 size={18}/> Tasks</button>
        <button className="side-btn"><Settings size={18}/> Settings</button>
        <div className="side-bottom"><span className="dot"/> {status}</div>
      </aside>

      <section className="chat">
        <header className="topbar">
          <div><h1>Nexa</h1><p>Personal AI assistant</p></div>
          <div className="status"><span className="dot"/> {status}</div>
        </header>

        <div className="messages">
          {messages.map((m, i) => (
            <div key={i} className={`row ${m.role}`}>
              <div className="avatar">{m.role === "nexa" ? <Sparkles size={17}/> : "U"}</div>
              <div className="bubble">{m.text}</div>
              {m.role === "nexa" && <button className="speak" onClick={() => speak(m.text)} title="Speak"><Volume2 size={15}/></button>}
            </div>
          ))}
        </div>

        <div className="composer-wrap">
          <div className="quick">
            <button onClick={() => send("Hello Nexa")}>Say hello</button>
            <button onClick={remember}>Remember something</button>
          </div>
          <div className="composer">
            <button className={`mic ${listening ? "live" : ""}`} onClick={startVoice}><Mic size={20}/></button>
            <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === "Enter" && send()} placeholder="Ask Nexa anything…" />
            <button className="send" onClick={() => send()}><Send size={19}/></button>
          </div>
        </div>
      </section>

      {showMemory && (
        <div className="overlay" onClick={() => setShowMemory(false)}>
          <div className="memory" onClick={e => e.stopPropagation()}>
            <div className="memory-head"><div><h2>Memory</h2><p>Stored locally on this device</p></div><button onClick={() => setShowMemory(false)}><X/></button></div>
            {memories.length === 0 ? <div className="empty">No memories yet.</div> :
              memories.map(m => <div className="memory-item" key={m.id}><Brain size={16}/>{m.text}</div>)}
          </div>
        </div>
      )}
    </main>
  );
}
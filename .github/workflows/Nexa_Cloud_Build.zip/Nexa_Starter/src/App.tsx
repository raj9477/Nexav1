import { useEffect, useMemo, useRef, useState } from 'react';
import { Bot, Brain, ChevronRight, Clock3, Mic, Plus, Send, Settings, Sparkles, Trash2, Volume2, X, Zap } from 'lucide-react';
import { askAI, clearApiKey, getApiKey, setApiKey, type ChatMessage } from './services/AIService';
import { addMemory, deleteMemory, getMemories, type MemoryItem } from './services/MemoryService';
import { listen, speak, stopSpeaking } from './services/VoiceService';

type Message = { id: string; role: 'user' | 'nexa'; text: string; time: number };
type Tab = 'assistant' | 'memory' | 'tasks' | 'settings';
const CHAT_KEY = 'nexa_chat_v2';

function loadMessages(): Message[] {
  try { const v = JSON.parse(localStorage.getItem(CHAT_KEY) || '[]'); return Array.isArray(v) && v.length ? v : [{ id: 'welcome', role: 'nexa', text: 'Nexa online. What can I help you with?', time: Date.now() }]; } catch { return []; }
}
function saveMessages(v: Message[]) { localStorage.setItem(CHAT_KEY, JSON.stringify(v.slice(-80))); }
function fmtTime(t: number) { return new Date(t).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); }

export default function App() {
  const [tab, setTab] = useState<Tab>('assistant');
  const [messages, setMessages] = useState<Message[]>(loadMessages);
  const [input, setInput] = useState('');
  const [listening, setListening] = useState(false);
  const [thinking, setThinking] = useState(false);
  const [memories, setMemories] = useState<MemoryItem[]>(getMemories);
  const [apiKey, setKey] = useState(getApiKey());
  const [autoSpeak, setAutoSpeak] = useState(true);
  const endRef = useRef<HTMLDivElement>(null);
  const voiceRef = useRef<{stop: () => void} | null>(null);

  useEffect(() => { saveMessages(messages); endRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);
  const history: ChatMessage[] = useMemo(() => messages.filter(m => m.id !== 'welcome').map(m => ({ role: m.role === 'nexa' ? 'model' : 'user', text: m.text })), [messages]);

  async function send(text = input) {
    const clean = text.trim(); if (!clean || thinking) return;
    const user: Message = { id: crypto.randomUUID(), role: 'user', text: clean, time: Date.now() };
    setMessages(m => [...m, user]); setInput(''); setThinking(true);
    try {
      const reply = await askAI(history, clean);
      const bot: Message = { id: crypto.randomUUID(), role: 'nexa', text: reply, time: Date.now() };
      setMessages(m => [...m, bot]); if (autoSpeak) speak(reply);
    } catch (e) {
      setMessages(m => [...m, { id: crypto.randomUUID(), role: 'nexa', text: e instanceof Error ? e.message : 'Something went wrong.', time: Date.now() }]);
    } finally { setThinking(false); }
  }
  function startVoice() {
    if (listening) { voiceRef.current?.stop(); return; }
    const s = listen(t => send(t), setListening); voiceRef.current = s;
    if (!s) alert('Voice recognition is not available on this device/browser.');
  }
  function remember() { const text = prompt('What should Nexa remember?'); if (!text?.trim()) return; addMemory(text.trim()); setMemories(getMemories()); }
  function newChat() { stopSpeaking(); setMessages([{ id: crypto.randomUUID(), role: 'nexa', text: 'New conversation ready.', time: Date.now() }]); }
  function saveSettings() { setApiKey(apiKey); }

  return <main className="shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark"><Sparkles size={20}/></div><div><strong>Nexa</strong><span>PERSONAL AI</span></div></div>
      <button className="new-chat" onClick={newChat}><Plus size={17}/> New chat</button>
      <nav>
        {([['assistant', Bot, 'Assistant'], ['memory', Brain, 'Memory'], ['tasks', Clock3, 'Tasks'], ['settings', Settings, 'Settings']] as const).map(([id, Icon, label]) => <button key={id} className={`nav-item ${tab === id ? 'active' : ''}`} onClick={() => setTab(id)}><Icon size={18}/>{label}<ChevronRight className="nav-arrow" size={14}/></button>)}
      </nav>
      <div className="side-footer"><div className="online"><span/> System online</div><small>Voice • Memory • AI</small></div>
    </aside>

    <section className="main">
      <header className="header"><div><div className="eyebrow"><Zap size={12}/> NEXA CORE</div><h1>{tab === 'assistant' ? 'Assistant' : tab[0].toUpperCase() + tab.slice(1)}</h1></div><div className="header-status"><span/> Online</div></header>

      {tab === 'assistant' && <>
        <div className="chat-area">
          {messages.map(m => <div key={m.id} className={`message ${m.role}`}>
            <div className="message-icon">{m.role === 'nexa' ? <Sparkles size={16}/> : 'U'}</div>
            <div className="message-body"><div className="message-meta">{m.role === 'nexa' ? 'Nexa' : 'You'} <time>{fmtTime(m.time)}</time></div><div className="bubble">{m.text}</div>
              {m.role === 'nexa' && <button className="mini-btn" onClick={() => speak(m.text)}><Volume2 size={14}/></button>}
            </div>
          </div>)}
          {thinking && <div className="message nexa"><div className="message-icon"><Sparkles size={16}/></div><div className="message-body"><div className="message-meta">Nexa</div><div className="bubble typing"><i/><i/><i/></div></div></div>}
          <div ref={endRef}/>
        </div>
        <div className="composer-area">
          <div className="quick-row"><button onClick={() => send('Hello Nexa')}>Say hello</button><button onClick={remember}>Remember something</button><button onClick={() => setTab('settings')}>Configure AI</button></div>
          <div className="composer"><button className={`mic ${listening ? 'active' : ''}`} onClick={startVoice}><Mic size={21}/></button><textarea value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } }} placeholder="Message Nexa…" rows={1}/><button className="send" onClick={() => send()} disabled={thinking}><Send size={19}/></button></div>
          <div className="hint">Enter to send • Shift + Enter for a new line</div>
        </div>
      </>}

      {tab === 'memory' && <div className="panel"><div className="panel-card"><div className="panel-title"><div><h2>Memory vault</h2><p>Stored locally on this device.</p></div><button className="icon-btn" onClick={() => { localStorage.removeItem('nexa_memories'); setMemories([]); }}><Trash2 size={17}/></button></div><button className="primary" onClick={remember}><Plus size={17}/> Add memory</button>{memories.length === 0 ? <div className="empty"><Brain size={30}/><b>No memories yet</b><span>Tell Nexa something worth remembering.</span></div> : memories.map(m => <div className="memory-row" key={m.id}><Brain size={16}/><span>{m.text}</span><button onClick={() => { deleteMemory(m.id); setMemories(getMemories()); }}><Trash2 size={15}/></button></div>)}</div></div>}

      {tab === 'tasks' && <div className="panel"><div className="panel-card"><div className="panel-title"><div><h2>Tasks</h2><p>Simple local task board for now.</p></div></div><div className="empty"><Clock3 size={30}/><b>Task system ready for expansion</b><span>Scheduled background actions require native Android integration.</span></div></div></div>}

      {tab === 'settings' && <div className="panel"><div className="panel-card settings-card"><div className="panel-title"><div><h2>Settings</h2><p>Configure Nexa without a forced login.</p></div></div><label>Gemini API key<input type="password" value={apiKey} onChange={e => setKey(e.target.value)} placeholder="Paste your API key here"/></label><p className="warning">The key is stored locally in this app. Do not put it in GitHub source code.</p><div className="setting-line"><div><b>Auto voice reply</b><span>Speak Nexa responses automatically.</span></div><input className="toggle" type="checkbox" checked={autoSpeak} onChange={e => setAutoSpeak(e.target.checked)}/></div><div className="actions"><button className="primary" onClick={saveSettings}>Save settings</button><button className="danger" onClick={() => { clearApiKey(); setKey(''); }}>Clear API key</button></div></div></div>}
    </section>
  </main>;
}

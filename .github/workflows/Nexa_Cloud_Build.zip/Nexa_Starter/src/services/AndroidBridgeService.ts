/**
 * Native Android actions will live here.
 * Keep the UI independent from Android APIs so we can add:
 * - app launching
 * - notification access
 * - contacts/calls
 * - media controls
 * - background service
 * - wake-word detection
 * in later phases.
 */
export const AndroidBridge = {
  async openApp(_packageName: string) {
    throw new Error("Native app launcher is not connected yet.");
  }
};
/** Native Android integration boundary. The current build intentionally does not fake
 * background execution, wake-word detection, app launching, contacts or notifications.
 * These require real Android native modules and permissions and can be added without
 * changing the Nexa chat UI.
 */
export const AndroidBridge = {
  async openApp(_packageName: string) { throw new Error('Native app launcher is not enabled in this build.'); }
};

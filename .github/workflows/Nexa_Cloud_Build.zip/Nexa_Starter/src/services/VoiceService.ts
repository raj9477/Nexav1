interface SpeechRecognitionEvent extends Event { results: SpeechRecognitionResultList; }
interface SpeechRecognition extends EventTarget {
  continuous: boolean; interimResults: boolean; lang: string;
  onresult: ((event: SpeechRecognitionEvent) => void) | null;
  onerror: ((event: Event) => void) | null; onend: (() => void) | null; onstart: (() => void) | null;
  start(): void; stop(): void;
}
type SpeechRecognitionCtor = new () => SpeechRecognition;
declare global { interface Window { SpeechRecognition?: SpeechRecognitionCtor; webkitSpeechRecognition?: SpeechRecognitionCtor; } }

export function speak(text: string, rate = 1) {
  if (!('speechSynthesis' in window)) return;
  window.speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text); u.rate = rate; u.pitch = 1; u.lang = 'en-IN';
  window.speechSynthesis.speak(u);
}
export function stopSpeaking() { window.speechSynthesis?.cancel(); }
export function listen(onText: (text: string) => void, onState?: (v: boolean) => void) {
  const Ctor = window.SpeechRecognition || window.webkitSpeechRecognition; if (!Ctor) return null;
  const r = new Ctor(); r.lang = 'en-IN'; r.interimResults = false; r.continuous = false;
  r.onstart = () => onState?.(true); r.onend = () => onState?.(false); r.onerror = () => onState?.(false);
  r.onresult = e => { const text = e.results[0]?.[0]?.transcript?.trim(); if (text) onText(text); };
  r.start(); return { stop: () => r.stop() };
}

export type ChatMessage = { role: 'user' | 'model'; text: string };

const KEY = 'nexa_gemini_api_key';
const MODEL = 'gemini-2.5-flash';

export function getApiKey() { return localStorage.getItem(KEY) || ''; }
export function setApiKey(key: string) { localStorage.setItem(KEY, key.trim()); }
export function clearApiKey() { localStorage.removeItem(KEY); }

export async function askAI(history: ChatMessage[], userText: string): Promise<string> {
  const key = getApiKey();
  if (!key) return 'AI brain is not configured yet. Open Settings and add your Gemini API key.';
  const contents = [...history.slice(-20), { role: 'user' as const, text: userText }].map(m => ({
    role: m.role,
    parts: [{ text: m.text }]
  }));
  const system = `You are Nexa, a concise, capable personal AI assistant. Be helpful, natural and direct. Do not claim to have device permissions or background abilities unless the app actually provides them. If a request is unsafe or illegal, refuse briefly and offer a safe alternative.`;
  const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent?key=${encodeURIComponent(key)}`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ systemInstruction: { parts: [{ text: system }] }, contents, generationConfig: { temperature: 0.7, maxOutputTokens: 800 } })
  });
  if (!res.ok) throw new Error(`AI request failed (${res.status})`);
  const data = await res.json();
  return data?.candidates?.[0]?.content?.parts?.map((p: {text?: string}) => p.text || '').join('').trim() || 'I could not generate a response.';
}

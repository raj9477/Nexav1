export type MemoryItem = { id: string; text: string; createdAt: number };
const KEY = 'nexa_memories';
export function getMemories(): MemoryItem[] { try { return JSON.parse(localStorage.getItem(KEY) || '[]'); } catch { return []; } }
export function addMemory(text: string) { const item = { id: crypto.randomUUID(), text, createdAt: Date.now() }; localStorage.setItem(KEY, JSON.stringify([item, ...getMemories()].slice(0, 100))); return item; }
export function deleteMemory(id: string) { localStorage.setItem(KEY, JSON.stringify(getMemories().filter(m => m.id !== id))); }
export function clearMemories() { localStorage.removeItem(KEY); }

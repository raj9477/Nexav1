export type MemoryItem = {
  id: string;
  text: string;
  createdAt: number;
};

const KEY = "nexa_memories";

export function getMemories(): MemoryItem[] {
  try { return JSON.parse(localStorage.getItem(KEY) || "[]"); }
  catch { return []; }
}

export function addMemory(text: string): MemoryItem {
  const item = { id: crypto.randomUUID(), text, createdAt: Date.now() };
  const next = [item, ...getMemories()].slice(0, 100);
  localStorage.setItem(KEY, JSON.stringify(next));
  return item;
}

export function clearMemories() {
  localStorage.removeItem(KEY);
}
# Nexa 2.0 — Final consolidated build

This build consolidates the app UI, AI chat layer, voice input/output, local memory, chat persistence, settings, and a polished mobile/desktop layout into one source package.

## Before using AI
Open Nexa → Settings → paste your Gemini API key → Save settings.

The key is stored locally in the app and is not included in source code. Do not commit an API key to GitHub.

## Included
- Premium dark assistant UI with responsive mobile layout
- Gemini AI chat integration
- Persistent local chat history
- Local memory vault with add/delete/clear
- Voice input through the device/browser speech recognizer
- Spoken Nexa replies with auto-speak toggle
- New chat control
- Assistant / Memory / Tasks / Settings navigation
- Clear error handling when AI is not configured

## Intentionally not faked
True always-on background wake-word detection, notification control, contacts/calls, media control, and arbitrary app launching require dedicated native Android services/permissions. The UI does not pretend those features are active when they are not.

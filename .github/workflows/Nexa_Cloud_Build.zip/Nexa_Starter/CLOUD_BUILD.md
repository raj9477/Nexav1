# Nexa — Cloud APK Build

This ZIP is prepared for a GitHub Actions cloud build.

## Phone-only build
1. Upload/extract this project to a GitHub repository.
2. Push it to the `main` branch.
3. Open the repository's **Actions** tab.
4. Run **Build Nexa APK**.
5. Download the `Nexa-debug-apk` artifact.

The project intentionally has no login requirement.

## Local development
npm install
npm run build

Android is generated during the GitHub Actions build with Capacitor.
